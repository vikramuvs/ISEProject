*************************************************
EDITING IS ONLY SUPPORTED IN PHPGRID FULL VERSION.

Why get full version?

. Full CRUD editing support
. Master detail
. WYSIWYG
. File upload
. Local array data source
. Composite primary key
. Grouping
. PDF export
. Multiple databases
. Premium themes
. ...and much more!

*************************************************
